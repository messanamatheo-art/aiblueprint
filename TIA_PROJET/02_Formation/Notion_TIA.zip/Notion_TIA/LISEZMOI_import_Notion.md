# Importer l'espace TIA dans Notion
1. Dans Notion, crée une page « Trading IA Academy ».
2. Menu ⋯ → Importer → CSV : importe `Prompts_IA.csv`, `Checklists.csv`, `Journal_de_trading.csv` et `Modules.csv`. Chacun devient une base de données.
3. Importe `Methode_DECISION.md` et `Workflows.md` (Importer → Texte et Markdown).
4. Dans la base Prompts, crée une vue groupée par « Étape DÉCISION ». Dans Checklists, une vue groupée par « Checklist ». Dans Journal, change « Plan respecté » en propriété Case à cocher.
5. Supprime la ligne EXEMPLE FICTIF du journal quand tu commences.
