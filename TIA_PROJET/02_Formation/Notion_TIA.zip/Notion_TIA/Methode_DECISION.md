# Méthode DÉCISION — Trading IA Academy

> Tu ne suis le signal de personne. Tu prends ta décision, avec l'IA comme copilote.

## D — Données (Collecte des données)
Rassembler le contexte avant toute analyse : calendrier économique, graphique sur 3 unités de temps, niveaux de la veille, état de ton journal.
- Outil : Checklist de préparation de séance
- Prompts : P01–P10

## É — Étude (Lecture du marché)
Décrire objectivement ce que fait le marché (tendance, zones, volatilité) sans chercher à prédire.
- Outil : Checklist multi-timeframe
- Prompts : P11–P30

## C — Copilote IA (Analyse IA)
Faire structurer, questionner et critiquer ta lecture par l'IA avec des prompts fermés. L'IA ne donne jamais d'ordre d'achat ou de vente.
- Outil : Checklist d'analyse avec IA
- Prompts : P31–P40

## I — Inspection (Vérification humaine)
Vérifier chaque affirmation de l'IA sur le graphique et les sources. Ce qui n'est pas vérifiable est écarté.
- Outil : Checklist de vérification d'une réponse IA
- Prompts : —

## S — Sécurité (Gestion du risque)
Fixer le risque en % du capital, le stop, la taille de position et les limites journalières AVANT d'entrer.
- Outil : Checklist de gestion du risque + Plan de risque (Excel)
- Prompts : P41–P50

## I — Intention (Planification)
Écrire le plan du trade : raison, scénario si/alors, invalidation, sortie. Pas de plan écrit, pas de trade.
- Outil : Plan de trading + Checklist avant d'ouvrir un trade
- Prompts : P51–P60

## O — Observation (Journalisation)
Noter chaque trade (y compris ceux qu'on n'a pas pris) : raison, respect du plan, émotion, résultat en R.
- Outil : Journal de trading (Excel / Notion)
- Prompts : P61–P75

## N — Nouvelle itération (Amélioration continue)
Chaque semaine et chaque mois : relire, mesurer la discipline, corriger UNE règle à la fois.
- Outil : Revue hebdo + Revue mensuelle
- Prompts : P76–P100
