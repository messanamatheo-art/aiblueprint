# Workflows TIA

## Quotidien (séance)
- [ ] Allumer le PC, fermer les réseaux sociais (2 min)
- [ ] D · Ouvrir le calendrier économique et noter les annonces (3 min)
- [ ] D · Relire la leçon d'hier dans le journal (2 min)
- [ ] É · Lecture multi-UT : UT longue → intermédiaire → courte (10 min)
- [ ] C · Faire structurer et critiquer la lecture par l'IA (P31, P37) (5 min)
- [ ] I · Vérifier chaque élément cité par l'IA (checklist vérification IA) (3 min)
- [ ] S · Rappeler les limites du jour, calculer la taille si une idée se présente (2 min)
- [ ] I · Écrire le scénario si/alors avant toute entrée (3 min)
- [ ] Exécution en compte démo, uniquement si la checklist « Avant d'ouvrir un trade » est entièrement cochée
- [ ] O · Noter chaque trade et chaque trade non pris dans le journal
- [ ] Checklist fin de journée, puis fermeture de la plateforme

## Hebdomadaire (dimanche, 45 min)
- [ ] Exporter les trades de la semaine (journal)
- [ ] Calculer : trades, respect du plan, R total, R moyen
- [ ] Identifier l'erreur la plus fréquente (tags)
- [ ] Prompt P76 : revue hebdomadaire
- [ ] Choisir UNE règle à ajuster (plan, checklist ou routine)
- [ ] Préparer la semaine : annonces, niveaux clés (P78, tableau de préparation hebdo)
- [ ] Fixer l'objectif d'apprentissage de la semaine

## Mensuel (fin de mois, 1 h 30)
- [ ] Remplir la revue mensuelle dans l'Excel
- [ ] Comparer avec le mois précédent (P81)
- [ ] Identifier le biais principal du mois (P86)
- [ ] Mettre à jour le plan de trading (nouvelle version datée)
- [ ] Mettre à jour les checklists (P85)
- [ ] Décider : rester en démo ou critères remplis pour le réel (checklist dédiée, P80)
- [ ] Fixer l'objectif d'apprentissage du mois suivant
